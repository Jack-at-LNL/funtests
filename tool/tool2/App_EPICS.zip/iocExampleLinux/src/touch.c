/*
 * C.E.A. IRFU/SIS/LDII
 *
 * @(#) $Id: touch.c,v 1.3 2011/01/21 13:22:38 cmsmgr Exp $
 *
 * touch.c
 *
 * IOC shell command to touch a file.
 */

#include <stdio.h>
#include <errno.h>

#include <epicsExport.h>
#include <iocsh.h>
#include <epicsTime.h>

/*
 * This is the command, which the vxWorks shell will call directly
 */
void touch(const char *path) {
    
    FILE *file;
    /*
    epicsTimeStamp ts;
    struct tm etm;
    unsigned long nano;
    char date[60];
    */
    
    if (path)
    {
	if ((file = fopen (path, "w")) == NULL)
	    perror("touch");
	else
	{
	    /*
	    epicsTimeGetCurrent (&ts);
  	    epicsTimeToTM (&etm, &nano, &ts);
  	    strftime (date, 59, "%c", &etm);
  	    fprintf (file, "IOC started %s\n", date);
  	    */
	    fclose (file);
	}
    }
}

/* 
 * Information needed by iocsh
 */
static const iocshArg     helloArg0 = {"path", iocshArgString};
static const iocshArg    *helloArgs[] = {&helloArg0};
static const iocshFuncDef helloFuncDef = {"touch", 1, helloArgs};

/* 
 * Wrapper called by iocsh, selects the argument types that hello needs
 */
static void helloCallFunc(const iocshArgBuf *args) {
    touch(args[0].sval);
}

/* 
 * Registration routine, runs at startup
 */
static void touchRegister(void) {
    iocshRegister(&helloFuncDef, helloCallFunc);
}
epicsExportRegistrar(touchRegister);
