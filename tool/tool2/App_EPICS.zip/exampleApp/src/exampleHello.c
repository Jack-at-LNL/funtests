/*
 * C.E.A. IRFU/SIS/LDII
 *
 * @(#) $Id: exampleHello.c,v 1.3 2011/01/21 13:22:38 cmsmgr Exp $
 *
 * exampleHello.c
 *
 * Example showing how to register a new ioc shell command
 */

#include <stdio.h>
#include <epicsExport.h>
#include <iocsh.h>

/*
 * This is the command, which the vxWorks shell will call directly
 */
void exampleHello(const char *name) {
    if (name) {
	printf("Hello %s\n", name);
    } else {
	printf("Hello\n");
    }
}

/* 
 * Information needed by iocsh
 */
static const iocshArg     helloArg0 = {"name", iocshArgString};
static const iocshArg    *helloArgs[] = {&helloArg0};
static const iocshFuncDef helloFuncDef = {"exampleHello", 1, helloArgs};

/* 
 * Wrapper called by iocsh, selects the argument types that hello needs
 */
static void helloCallFunc(const iocshArgBuf *args) {
    exampleHello(args[0].sval);
}

/* 
 * Registration routine, runs at startup
 */
static void exampleHelloRegister(void) {
    iocshRegister(&helloFuncDef, helloCallFunc);
}
epicsExportRegistrar(exampleHelloRegister);
