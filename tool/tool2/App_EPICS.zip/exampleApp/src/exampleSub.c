/*
 * C.E.A. IRFU/SIS/LDII
 *
 * @(#) $Id: exampleSub.c,v 1.3 2011/01/21 13:22:38 cmsmgr Exp $
 *
 * exampleSub.c
 *
 * Example showing how to register init and process functions 
 * for a subroutine record.
 */

#include <stdio.h>
#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <epicsExport.h>

/* 
 * Debug variable
 */
int exampleSubDebug;

typedef long (*processMethod)(subRecord *precord);

/* 
 * Subroutine record init function
 */
static long exampleSubInit(subRecord *precord,processMethod process)
{
    if (exampleSubDebug)
        printf("Record %s called exampleSubInit(%p, %p)\n",
               precord->name, (void*) precord, (void*) process);
    return(0);
}

/* 
 * Subroutine record process function
 */
static long exampleSubProcess(subRecord *precord)
{
    if (exampleSubDebug)
        printf("Record %s called exampleSubProcess(%p)\n",
               precord->name, (void*) precord);
    return(0);
}

/* 
 * Register these symbols for use by IOC code
 */
epicsExportAddress(int, exampleSubDebug);
epicsRegisterFunction(exampleSubInit);
epicsRegisterFunction(exampleSubProcess);
